// Configure seu Firebase aqui
const firebaseConfig = {
  apiKey:"",
  authDomain:"",
  projectId:"",
  storageBucket:"",
  messagingSenderId:"",
  appId:""
};

// Inicialização será adicionada posteriormente.
