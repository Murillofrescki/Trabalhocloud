# Arquitetura

Cliente
↓
Azure App Service
↓
Azure SQL Database
↓
Azure Blob Storage
↓
Azure Monitor
↓
Application Insights
↓
Recovery Services Vault

Protótipo implementado inicialmente com Firebase para acelerar o desenvolvimento.
